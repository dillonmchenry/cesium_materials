import React from "react";
import MaterialsMenu from "./MaterialsMenu";

function App() {
  return (
    <div className="App">
      <MaterialsMenu />
    </div>
  );
}

export default App;
