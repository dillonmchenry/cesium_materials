# Cesium Materials Project
Created by Dillon McHenry
##How to run
This is a react application created using "create-react-app". In order to run this application locally, you'll need to navigate inside the project directory and run "npm install" followed by "npm start". The project should now be hosted through "localhost".

## Reflection

I spent around four hours working on this project over the course of two sessions. The finally hour mostly consisted of experimenting with jest testing.

In terms of what I completed, I created a fully functional front-end experience for the material menu using React components. I added a few jest tests with remaining time. I was not able to mock an api call in the alloted time.

